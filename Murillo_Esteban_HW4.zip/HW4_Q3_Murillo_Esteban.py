# Esteban Murillo
# ITP 449
# HW4
# Question 3

import matplotlib.pyplot as plt

# Get user input
loan_amount = float(input("Enter the loan amount: "))
annual_interest_rate = float(input("Enter the annual interest rate: "))
years = int(input("Enter the number of years: "))

# having the user input

# Calculate monthly interest rate and number of payments
monthly_interest_rate = annual_interest_rate / 12 / 100
num_payments = years * 12

# Calculate monthly payment
monthly_payment = (loan_amount * monthly_interest_rate * (1 + monthly_interest_rate) ** num_payments /
                   ((1 + monthly_interest_rate) ** num_payments - 1))

# Print monthly payment
print(f"Your monthly payment is: ${monthly_payment:.2f}")

# Calculate monthly interest and principal balance
monthly_interest = []
principal_balance = []
mv_bl = loan_amount

for month in range(1, num_payments + 1):
    interest_paid = mv_bl * monthly_interest_rate
    mv_bl = mv_bl + interest_paid - monthly_payment
    monthly_interest.append(interest_paid)
    principal_balance.append(mv_bl)

# Creating subplots
fig, axs = plt.subplots(1, 2, figsize=(10, 5))

# Plot monthly interest
axs[0].plot(range(1, num_payments + 1), monthly_interest, label='Monthly Interest', color='blue', marker='o',
            linewidth = .5)
axs[0].set_xlabel('Month')
axs[0].set_ylabel('Interest Paid')


# Plot principal balance
axs[1].plot(range(1, num_payments + 1), principal_balance, label='Principal Balance', color='blue', marker='o',
            linewidth = .5)
axs[1].set_xlabel('Month')
axs[1].set_ylabel('Loan Balance')


# Show the plots
plt.tight_layout()
plt.show()